var json = {
  "status":"success",
  "data":{
    "items":[
      {"name":"Country Cottages & Ecomac Sheds","id":"48507","image":"","arrow":"plain","distance":"414","city":"Levin","desc":""},
      {"name":"Hamish Macdougall","id":"45729","image":"","arrow":"plain","distance":"415","city":"Levin","desc":""},
      {"name":"Fairfield Educare Ltd","id":"52138","image":"","arrow":"plain","distance":"415","city":"Levin","desc":""},
      {"name":"Levin Playcentre","id":"52149","image":"","arrow":"plain","distance":"415","city":"Levin","desc":""},
      {"name":"Hanratty DJ Ltd","id":"45730","image":"","arrow":"plain","distance":"415","city":"Levin","desc":""},
      {"name":"Ian Taylor","id":"48703","image":"","arrow":"plain","distance":"415","city":"Levin","desc":""},
      {"name":"Harcourts Levin","id":"12268","image":"","arrow":"plain","distance":"416","city":"Levin","desc":""},
      {"name":"Ace Home Improvement","id":"48503","image":"","arrow":"plain","distance":"416","city":"Levin","desc":""},
      {"name":"AMI Levin","id":"14085","image":"","arrow":"plain","distance":"416","city":"Levin","desc":""},
      {"name":"Fluker Denton & Co","id":"45727","image":"","arrow":"plain","distance":"416","city":"Levin","desc":""},
      {"name":"Harveys Levin","id":"14206","image":"","arrow":"plain","distance":"416","city":"Levin","desc":""},
      {"name":"Ray White Levin","id":"7482","image":"","arrow":"plain","distance":"416","city":"Levin","desc":""},
      {"name":"Spicer & Associates Ltd","id":"45737","image":"","arrow":"plain","distance":"416","city":"Levin","desc":""},
      {"name":"Kereru Children's Learning Centre","id":"52146","image":"","arrow":"plain","distance":"416","city":"Levin","desc":""},
      {"name":"Levin & Horowhenua Veterinary Centre Ltd","id":"16610","image":"","arrow":"plain","distance":"416","city":"Levin","desc":""},
      {"name":"Professionals Winkel Real Estate Ltd MREINZ Levin","id":"9278","image":"","arrow":"plain","distance":"416","city":"Levin","desc":""},
      {"name":"Levin Baptist Kindergarten","id":"52148","image":"","arrow":"plain","distance":"416","city":"Levin","desc":""},
      {"name":"KCP Physiotherapy Levin","id":"64747","image":"","arrow":"plain","distance":"416","city":"Levin","desc":""},
      {"name":"Plunket Levin","id":"55929","image":"","arrow":"plain","distance":"416","city":"Levin","desc":""},
      {"name":"ABC Building Contractor Ltd","id":"48504","image":"","arrow":"plain","distance":"416","city":"Levin","desc":""}
    ]
  },
  "total_items":31,
  "total_pages":2,
  "current_items":20,
  "current_page":"1",
  "last_update":"20110921023436"
};
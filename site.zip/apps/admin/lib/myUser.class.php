<?php

class myUser extends sfGuardSecurityUser
{
}
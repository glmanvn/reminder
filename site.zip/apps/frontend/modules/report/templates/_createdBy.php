<strong><?php echo $Task->getUser()->getFirstName() . ' ' . $Task->getUser()->getLastName(); ?></strong>
<br />
<?php echo $Task->getCreatedAt(); ?>
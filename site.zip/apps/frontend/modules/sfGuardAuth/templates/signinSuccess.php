<?php echo get_partial('sfGuardAuth/signin_form', array('form' => $form)) ?>

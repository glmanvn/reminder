<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

echo $Task->getUser()->getFirstName() . ' ' . $Task->getUser()->getLastName();

?>

<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<input type="hidden" id="userId" name="userId" value="" />
<input type="text" id="userName" />
<input type="button" value="Chọn người chuyển giao" onclick="openUserDialog();" />

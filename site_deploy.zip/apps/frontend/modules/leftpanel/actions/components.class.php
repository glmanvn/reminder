<?php

class leftpanelComponents extends sfComponents {

    /**
     * 
     * @param sfWebRequest $request
     */
    public function executeTask(sfWebRequest $request) {
        
    }

    /**
     * 
     * @param sfWebRequest $request
     */
    public function executeHome(sfWebRequest $request) {
        
    }

}

<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="clearfix">&nbsp;</div>
<h2>QUẢN TRỊ CÔNG VIỆC</h2>

<ul>
  <li><?php echo link_to('Danh sách', 'task/index?page=1') ?></li>
  <li><?php echo link_to('Tạo mới Ticket', 'task/new') ?></li>
</ul>
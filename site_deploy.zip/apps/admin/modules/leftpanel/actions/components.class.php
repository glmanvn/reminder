<?php


class leftpanelComponents extends sfComponents
{
  public function executeUser(sfWebRequest $request)
  {
    
  }
}
